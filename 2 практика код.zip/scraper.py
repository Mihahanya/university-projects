"""Учебный веб-скрапер каталога новостей Georgia Tech.

Перед запуском:
1) проверьте актуальные условия использования сайта;
2) если они не запрещают выбранный способ работы, установите TERMS_REVIEWED = True;
3) сам скрипт дополнительно проверит robots.txt и остановится, если проверка не пройдена.

Собираются только метаданные списка: заголовок, дата, раздел, ссылка и источник страницы.
Тексты статей, имена авторов, адреса электронной почты и иные данные людей не собираются.
"""
from __future__ import annotations

import json
import logging
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse, urldefrag
from urllib.robotparser import RobotFileParser

import pandas as pd
import requests
from bs4 import BeautifulSoup, Tag
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ------------------------- Configuration -------------------------
BASE_URL = "https://news.gatech.edu"
CATEGORY_URL = f"{BASE_URL}/categories/science-and-technology"
CATEGORY_NAME = "Science and Technology"
USER_AGENT = "StudentMetadataScraper/1.0 (educational use; metadata only)"

# Read the current site's terms before collection. Do not change to True if scraping
# is expressly prohibited or permission is required and has not been obtained.
TERMS_REVIEWED = True

START_PAGE = 0  # Drupal-style listing URLs use page=0 for the first page.
MAX_PAGES = 10  # Limit collection to at most 10 pages.
TARGET_RECORDS = 80  # Stop when enough metadata rows have been collected.
REQUEST_DELAY_SECONDS = 2.0  # Minimum delay between listing-page requests.
TIMEOUT_SECONDS = 20
MAX_CONSECUTIVE_PAGE_ERRORS = 2
OUTPUT_DIR = Path(__file__).resolve().parent

DATA_FILE = OUTPUT_DIR / "news_dataset.csv"
LOG_FILE = OUTPUT_DIR / "collector.log"
ROBOTS_FILE = OUTPUT_DIR / "robots_snapshot.txt"
POLICY_FILE = OUTPUT_DIR / "policy_check.txt"
SUMMARY_FILE = OUTPUT_DIR / "run_summary.json"
RESULTS_FILE = OUTPUT_DIR / "run_results.md"

COLUMNS = ["title", "published_date", "category", "url", "source_page", "collected_at_utc"]


class PolicyCheckError(RuntimeError):
    """Raised when the crawler cannot establish permission to request a URL."""


def setup_logging() -> logging.Logger:
    logger = logging.getLogger("student_scraper")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler = logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


def make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en-US,en;q=0.8",
    })
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        status=3,
        backoff_factor=1.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET"}),
        respect_retry_after_header=True,
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def check_robots(session: requests.Session, logger: logging.Logger) -> RobotFileParser:
    robots_url = urljoin(BASE_URL, "/robots.txt")
    logger.info("Проверка robots.txt: %s", robots_url)
    try:
        response = session.get(robots_url, timeout=TIMEOUT_SECONDS)
    except requests.RequestException as exc:
        raise PolicyCheckError(f"Не удалось получить robots.txt: {exc}") from exc

    if response.status_code != 200:
        raise PolicyCheckError(
            f"robots.txt вернул HTTP {response.status_code}; сбор остановлен по принципу fail-closed."
        )
    text = response.text
    # An HTML error page returned with 200 is not a valid robots file.
    if "<html" in text[:500].lower() and "user-agent:" not in text.lower():
        raise PolicyCheckError("Вместо robots.txt получен HTML-документ; сбор остановлен.")

    ROBOTS_FILE.write_text(
        f"URL: {robots_url}\nFetched at UTC: {datetime.now(timezone.utc).isoformat()}\n"
        f"HTTP status: {response.status_code}\n\n{text}",
        encoding="utf-8",
    )
    parser = RobotFileParser()
    parser.set_url(robots_url)
    parser.parse(text.splitlines())

    test_urls = [f"{CATEGORY_URL}?page={i}" for i in range(START_PAGE, START_PAGE + MAX_PAGES)]
    disallowed = [url for url in test_urls if not parser.can_fetch(USER_AGENT, url)]
    report = [
        f"robots_url={robots_url}",
        f"checked_at_utc={datetime.now(timezone.utc).isoformat()}",
        f"http_status={response.status_code}",
        f"user_agent={USER_AGENT}",
        f"candidate_pages_checked={len(test_urls)}",
        f"disallowed_pages={len(disallowed)}",
    ]
    report.extend(f"DISALLOWED: {url}" for url in disallowed)
    POLICY_FILE.write_text("\n".join(report) + "\n", encoding="utf-8")

    if disallowed:
        raise PolicyCheckError(
            "robots.txt запрещает запрошенный раздел или часть диапазона страниц. "
            "Никакие запросы к страницам списка не отправлялись. См. policy_check.txt."
        )
    logger.info("robots.txt получен; все %d URL разрешены для указанного User-Agent.", len(test_urls))
    return parser


def get_page_url(page_number: int) -> str:
    return f"{CATEGORY_URL}?page={page_number}"


def get_cards(soup: BeautifulSoup) -> tuple[list[Tag], str]:
    """Find listing cards, preferring Drupal Views rows."""
    cards = soup.select(".views-row")
    if len(cards) >= 3:
        return cards, ".views-row"

    # Fallback for a future redesign. This path is logged for later selector verification.
    articles = soup.select("main article, #main-content article, article")
    if len(articles) >= len(cards) and articles:
        return articles, "main article / #main-content article / article"

    return cards, ".views-row"


def normalize_url(href: str, page_url: str) -> str | None:
    href = (href or "").strip()
    if not href or href.startswith(("mailto:", "javascript:")):
        return None
    full, _fragment = urldefrag(urljoin(page_url, href))
    parsed = urlparse(full)
    if parsed.scheme not in {"http", "https"} or parsed.netloc.lower() != "news.gatech.edu":
        return None
    return full.rstrip("/")


def first_select(card: Tag, selectors: list[str]) -> tuple[Tag | None, str | None]:
    for selector in selectors:
        element = card.select_one(selector)
        if element is not None:
            return element, selector
    return None, None


def extract_card(card: Tag, page_url: str, card_selector: str) -> dict[str, Any] | None:
    title_el, title_selector = first_select(card, [
        ".views-field-title a", ".field--name-title a", "h2 a", "h3 a", "h4 a", "a[rel='bookmark']"
    ])
    if title_el is None:
        # A card might itself contain a heading without the usual linked title field.
        title_el, title_selector = first_select(card, ["h2", "h3", "h4"])
    title = " ".join((title_el.get_text(" ", strip=True) if title_el else "").split())
    href = title_el.get("href", "") if title_el else ""
    item_url = normalize_url(href, page_url)
    if not title or not item_url:
        return None

    date_el, date_selector = first_select(card, [
        "time[datetime]", "time", ".views-field-created", ".field--name-created", "[class*='date']"
    ])
    published_date = ""
    if date_el is not None:
        published_date = (date_el.get("datetime") or date_el.get_text(" ", strip=True) or "").strip()
        published_date = " ".join(published_date.split())

    return {
        "title": title,
        "published_date": published_date,
        "category": CATEGORY_NAME,
        "url": item_url,
        "source_page": page_url,
        "collected_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "_card_selector": card_selector,
        "_title_selector": title_selector or "not found",
        "_date_selector": date_selector or "not found",
    }


def parse_listing(html: str, page_url: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    cards, card_selector = get_cards(soup)
    records = []
    selector_counts: Counter[str] = Counter()
    for card in cards:
        record = extract_card(card, page_url, card_selector)
        if record:
            selector_counts[f"card={record.pop('_card_selector')}; title={record.pop('_title_selector')}; date={record.pop('_date_selector')}"] += 1
            records.append(record)
    diagnostics = {
        "card_count_detected": len(cards),
        "records_extracted": len(records),
        "card_container_selector": card_selector,
        "selector_combinations": dict(selector_counts),
    }
    return records, diagnostics


def date_range(series: pd.Series) -> dict[str, str | None]:
    if series.empty:
        return {"min": None, "max": None}
    parsed = pd.to_datetime(series.astype(str), errors="coerce", utc=True)
    valid = parsed.dropna()
    if valid.empty:
        return {"min": None, "max": None}
    return {"min": valid.min().date().isoformat(), "max": valid.max().date().isoformat()}


def build_results_markdown(df: pd.DataFrame, summary: dict[str, Any]) -> str:
    lines = [
        "# Результаты запуска скрапера — Georgia Tech News Center",
        "",
        f"- Время запуска (UTC): {summary.get('started_at_utc', '—')}",
        f"- Время завершения (UTC): {summary.get('finished_at_utc', '—')}",
        f"- Страниц обработано: {summary.get('pages_succeeded', 0)} из {summary.get('pages_attempted', 0)}",
        f"- Извлечено уникальных записей: {len(df)}",
        f"- Дубликаты ссылок до удаления: {summary.get('duplicate_urls_removed', 0)}",
        f"- Диапазон дат публикаций: {summary.get('published_date_range', {}).get('min') or 'не определён'} — {summary.get('published_date_range', {}).get('max') or 'не определён'}",
        "",
        "## Пропуски по столбцам",
        "",
        "| Поле | Пропусков |",
        "|---|---:|",
    ]
    for col in COLUMNS:
        count = int(df[col].isna().sum() + (df[col].astype(str).str.strip() == "").sum()) if col in df else 0
        lines.append(f"| `{col}` | {count} |")
    lines += ["", "## Первые 15 записей", "", "| № | Заголовок | Дата | Раздел | URL |", "|---:|---|---|---|---|"]
    for i, row in df.head(15).iterrows():
        title = str(row["title"]).replace("|", "\\|").replace("\n", " ")
        date = str(row["published_date"]).replace("|", "\\|")
        url = str(row["url"])
        lines.append(f"| {i + 1} | {title} | {date} | {CATEGORY_NAME} | [Открыть]({url}) |")
    lines += [
        "",
        "## Методические замечания",
        "",
        "Файл создан скриптом автоматически. Перед включением чисел в отчёт проверьте `collector.log`, `policy_check.txt` и исходный CSV. Если дат публикации нет в HTML-карточках, это отражается как пропуски и не заполняется предположениями.",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    logger = setup_logging()
    started_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    logger.info("Старт учебного сбора метаданных; раздел=%s", CATEGORY_URL)
    logger.info("Лимиты: max_pages=%d, target_records=%d, delay=%.1f сек.", MAX_PAGES, TARGET_RECORDS, REQUEST_DELAY_SECONDS)

    if not TERMS_REVIEWED:
        message = (
            "Сбор не запущен: TERMS_REVIEWED=False. Перед сбором вручную проверьте актуальные "
            "условия использования News Center и применимые правила использования контента. "
            "Если автоматический сбор запрещён или требуется разрешение, не меняйте этот флаг. "
            "Если проверка завершена и препятствий нет, установите TERMS_REVIEWED=True в scraper.py."
        )
        POLICY_FILE.write_text(message + "\n", encoding="utf-8")
        logger.error(message)
        return 2

    session = make_session()
    try:
        check_robots(session, logger)
    except PolicyCheckError as exc:
        logger.error("Проверка политики не пройдена: %s", exc)
        POLICY_FILE.write_text(POLICY_FILE.read_text(encoding="utf-8") + f"\nRESULT: STOPPED\nReason: {exc}\n" if POLICY_FILE.exists() else f"RESULT: STOPPED\nReason: {exc}\n", encoding="utf-8")
        return 2
    except requests.RequestException as exc:
        logger.exception("Сетевая ошибка при проверке robots.txt: %s", exc)
        return 2

    all_records: list[dict[str, Any]] = []
    page_diagnostics: list[dict[str, Any]] = []
    pages_attempted = 0
    pages_succeeded = 0
    consecutive_errors = 0
    seen_urls: set[str] = set()
    duplicate_count = 0

    for page_number in range(START_PAGE, START_PAGE + MAX_PAGES):
        if len(all_records) >= TARGET_RECORDS:
            logger.info("Достигнута целевая выборка (%d записей); остановка.", TARGET_RECORDS)
            break
        page_url = get_page_url(page_number)
        pages_attempted += 1
        logger.info("Страница %d/%d: GET %s", page_number + 1, MAX_PAGES, page_url)
        try:
            response = session.get(page_url, timeout=TIMEOUT_SECONDS)
            if response.status_code in (401, 403, 404, 410):
                raise PolicyCheckError(f"Страница вернула HTTP {response.status_code}; дальнейший обход остановлен.")
            response.raise_for_status()
            if "text/html" not in response.headers.get("Content-Type", "text/html").lower():
                raise ValueError(f"Ожидался HTML, получен Content-Type={response.headers.get('Content-Type')}")
            records, diagnostics = parse_listing(response.text, page_url)
            diagnostics.update({"page_number": page_number, "url": page_url, "http_status": response.status_code})
            page_diagnostics.append(diagnostics)
            pages_succeeded += 1
            consecutive_errors = 0
            logger.info(
                "Страница %d: HTTP %d, карточек=%d, извлечено=%d, селектор карточки=%s",
                page_number + 1, response.status_code, diagnostics["card_count_detected"],
                diagnostics["records_extracted"], diagnostics["card_container_selector"]
            )
            if not records:
                logger.warning("Записей не найдено; предполагается конец списка или изменение структуры. Обход остановлен.")
                break

            new_on_page = 0
            for record in records:
                if record["url"] in seen_urls:
                    duplicate_count += 1
                    continue
                seen_urls.add(record["url"])
                all_records.append(record)
                new_on_page += 1
            logger.info("Новых уникальных записей на странице: %d; накоплено: %d", new_on_page, len(all_records))
        except PolicyCheckError as exc:
            logger.error("Политическая/доступная ошибка на странице %d: %s; обход остановлен.", page_number, exc)
            break
        except (requests.RequestException, ValueError, AttributeError) as exc:
            consecutive_errors += 1
            logger.exception("Не удалось обработать страницу %d: %s", page_number, exc)
            page_diagnostics.append({"page_number": page_number, "url": page_url, "error": str(exc)})
            if consecutive_errors >= MAX_CONSECUTIVE_PAGE_ERRORS:
                logger.error("Достигнут предел последовательных ошибок (%d); остановка.", MAX_CONSECUTIVE_PAGE_ERRORS)
                break
        if page_number < START_PAGE + MAX_PAGES - 1 and len(all_records) < TARGET_RECORDS:
            time.sleep(REQUEST_DELAY_SECONDS)

    df = pd.DataFrame(all_records, columns=COLUMNS)
    # Final QA: discard duplicate canonical URLs and retain empty values as missing, not invented data.
    if not df.empty:
        before = len(df)
        df = df.drop_duplicates(subset=["url"], keep="first").reset_index(drop=True)
        duplicate_count += before - len(df)
        for col in COLUMNS:
            df[col] = df[col].replace(r"^\s*$", pd.NA, regex=True)
    df.to_csv(DATA_FILE, index=False, encoding="utf-8-sig")

    missing_counts = {
        col: int(df[col].isna().sum()) if col in df else 0
        for col in COLUMNS
    }
    summary: dict[str, Any] = {
        "started_at_utc": started_at,
        "finished_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": BASE_URL,
        "category_url": CATEGORY_URL,
        "category": CATEGORY_NAME,
        "user_agent": USER_AGENT,
        "pages_attempted": pages_attempted,
        "pages_succeeded": pages_succeeded,
        "page_diagnostics": page_diagnostics,
        "records_saved": len(df),
        "duplicate_urls_removed": duplicate_count,
        "missing_by_column": missing_counts,
        "published_date_range": date_range(df["published_date"]) if "published_date" in df else {"min": None, "max": None},
        "csv_path": str(DATA_FILE),
        "robots_snapshot_path": str(ROBOTS_FILE),
        "policy_check_path": str(POLICY_FILE),
        "limitations": [
            "Собираются только метаданные карточек, а не тексты статей.",
            "HTML-разметка сайта может измениться; селекторы следует перепроверить в браузере.",
            "Количество и даты публикаций ограничены выбранной категорией и лимитом страниц.",
        ],
    }
    SUMMARY_FILE.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    RESULTS_FILE.write_text(build_results_markdown(df, summary), encoding="utf-8")
    logger.info("Готово: строк=%d, страниц успешно=%d/%d, дубликатов URL удалено=%d", len(df), pages_succeeded, pages_attempted, duplicate_count)
    logger.info("Сохранены: %s, %s, %s, %s", DATA_FILE.name, SUMMARY_FILE.name, RESULTS_FILE.name, LOG_FILE.name)
    if len(df) < 60:
        logger.warning("Получено меньше 60 записей. Укажите это в отчёте; не заявляйте требуемый объём как достигнутый.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
