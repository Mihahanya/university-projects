# Результаты запуска скрапера — Georgia Tech News Center

- Время запуска (UTC): 2026-10-24T11:47:49+00:00
- Время завершения (UTC): 2026-10-24T11:48:07+00:00
- Страниц обработано: 8 из 8
- Извлечено уникальных записей: 80
- Дубликаты ссылок до удаления: 0
- Диапазон дат публикаций: 2025-10-13 — 2026-10-13

## Пропуски по столбцам

| Поле | Пропусков |
|---|---:|
| `title` | 0 |
| `published_date` | 0 |
| `category` | 0 |
| `url` | 0 |
| `source_page` | 0 |
| `collected_at_utc` | 0 |

## Первые 15 записей

| № | Заголовок | Дата | Раздел | URL |
|---:|---|---|---|---|
| 1 | Can We Detect Harmful AI Before It’s Too Late? Researchers Search for Warning Signs | 2026-10-13T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/10/13/can-we-detect-harmful-ai-its-too-late-researchers-search-warning-signs) |
| 2 | Georgia Tech Receives $5 Million From Google.org to Expand Access to AI for Scientific Discovery | 2026-10-09T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/10/09/georgia-tech-receives-5-million-googleorg-expand-access-ai-scientific-discovery) |
| 3 | Georgia Tech and Amazon Launch Joint Science Hub | 2026-10-02T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/10/02/georgia-tech-and-amazon-launch-joint-science-hub) |
| 4 | The ‘WarGames’ Problem: Computer Science Has Long Understood What it Takes to Keep AI Under Control | 2026-09-29T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/29/wargames-problem-computer-science-has-long-understood-what-it-takes-keep-ai-under) |
| 5 | GT Cybersecurity Expert Helping to Chart the Future of AI on the Energy Grid | 2026-09-25T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/25/gt-cybersecurity-expert-helping-chart-future-ai-energy-grid) |
| 6 | New Benchmark Measures Memory Capabilities of VLM-Powered Robots | 2026-09-24T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/24/new-benchmark-measures-memory-capabilities-vlm-powered-robots) |
| 7 | Study Uncovers Security Weaknesses in Next-Generation Vehicle Technology | 2026-09-24T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/24/study-uncovers-security-weaknesses-next-generation-vehicle-technology) |
| 8 | Georgia Tech’s Avant South Brings ‘AI in Action’ to Atlanta | 2026-09-15T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/15/georgia-techs-avant-south-brings-ai-action-atlanta) |
| 9 | From Coding to Cabernet: An Alumnus’ Journey From Corporate Tech to Startup Life | 2026-09-08T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/08/coding-cabernet-alumnus-journey-corporate-tech-startup-life) |
| 10 | New Center Seeks to Unlock the Science of Turbulence for Energy, Flight, and Discovery | 2026-09-01T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/01/new-center-seeks-unlock-science-turbulence-energy-flight-and-discovery) |
| 11 | Many Space Missions Are Searching for Life Beyond Earth – But Are We Prepared for the Fallout if They Succeed? | 2026-09-01T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/09/01/many-space-missions-are-searching-life-beyond-earth-are-we-prepared-fallout-if-they) |
| 12 | Georgia Tech's Shield Research Environment Earns Top Rating in Federal Cybersecurity Assessment | 2026-08-20T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/08/20/georgia-techs-shield-research-environment-earns-top-rating-federal-cybersecurity) |
| 13 | New Model Teaches Workplace AI to Read More Like Humans | 2026-08-12T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/08/12/new-model-teaches-workplace-ai-read-more-humans) |
| 14 | Georgia Tech Strengthens Atlanta's Innovation Ecosystem Through Tech Square Tech Hop and Avant South | 2026-08-07T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/08/07/georgia-tech-strengthens-atlantas-innovation-ecosystem-through-tech-square-tech-hop) |
| 15 | Georgia Tech to Lead National Cloud Laboratory for Advanced Manufacturing and Materials | 2026-08-03T12:00:00Z | Science and Technology | [Открыть](https://news.gatech.edu/news/2026/08/03/georgia-tech-lead-national-cloud-laboratory-advanced-manufacturing-and-materials) |

## Методические замечания

Файл создан скриптом автоматически. Перед включением чисел в отчёт проверьте `collector.log`, `policy_check.txt` и исходный CSV. Если дат публикации нет в HTML-карточках, это отражается как пропуски и не заполняется предположениями.
