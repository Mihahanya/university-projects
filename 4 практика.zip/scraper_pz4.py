"""ПЗ4: сбор данных с динамической страницы (Load more) через Playwright.

Цель: https://www.scrapingcourse.com/button-click  (учебная площадка для скрапинга).
Запуск:
    pip install playwright pandas requests
    playwright install chromium
    python scraper_pz4.py

Скрипт сам пишет: dynamic_page_dataset.csv, collector_pz4.log, metrics.json,
network_log.json (список XHR/fetch-запросов для этапа 5), robots_snapshot.txt.
Никаких чисел в отчёт руками не вписывайте: берите их из metrics.json и лога.
"""
import json
import logging
import sys
import time
import urllib.robotparser
from datetime import datetime, timezone

import pandas as pd
import requests
from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright

S = requests.Session()
S.trust_env = False

TARGET_URL = "https://www.scrapingcourse.com/button-click"
ROBOTS_URL = "https://www.scrapingcourse.com/robots.txt"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

# Селекторы по классам (не абсолютные XPath). ПРОВЕРЬТЕ их вручную в DevTools
# и при расхождении поправьте здесь.
CARD = ".product-item"
TITLE = ".product-name"
PRICE = ".product-price"
LINK = "a"
LOAD_MORE = "#load-more-btn"

MIN_RECORDS = 150
MAX_ROUNDS = 40          # предел итераций
CLICK_DELAY_S = 1.0      # вежливая пауза между кликами (не замена ожиданию)
WAIT_TIMEOUT_MS = 8_000

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler("collector_pz4.log", encoding="utf-8"), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("pz4")


def check_static():
    """Этап 1: requests не видит динамические данные."""
    resp = S.get(TARGET_URL, headers={"User-Agent": USER_AGENT}, timeout=20)
    n_cards = resp.text.count("product-item")
    has_btn = "load-more-btn" in resp.text
    log.info("requests: HTTP %s, %d байт, вхождений '%s' в HTML: %d, кнопка в HTML: %s",
             resp.status_code, len(resp.text), CARD.lstrip("."), n_cards, has_btn)
    return {"status": resp.status_code, "bytes": len(resp.text), "card_marker_count": n_cards, "button_in_html": has_btn}


def check_robots():
    """Fail-closed проверка robots.txt, как в ПЗ2."""
    r = S.get(ROBOTS_URL, headers={"User-Agent": USER_AGENT}, timeout=20)
    with open("robots_snapshot.txt", "w", encoding="utf-8") as f:
        f.write(f"URL: {ROBOTS_URL}\nHTTP status: {r.status_code}\nFetched UTC: {datetime.now(timezone.utc).isoformat()}\n\n{r.text}")
    if r.status_code != 200:
        log.error("robots.txt недоступен (HTTP %s) — остановка", r.status_code)
        sys.exit(1)
    rp = urllib.robotparser.RobotFileParser()
    rp.parse(r.text.splitlines())
    if not rp.can_fetch(USER_AGENT, TARGET_URL):
        log.error("robots.txt запрещает %s — остановка", TARGET_URL)
        sys.exit(1)
    log.info("robots.txt: обход %s разрешён", TARGET_URL)


def extract(page):
    return page.eval_on_selector_all(
        CARD,
        """(els, sel) => els.map(e => ({
            title: (e.querySelector(sel.t)?.innerText || '').trim() || null,
            price: (e.querySelector(sel.p)?.innerText || '').trim() || null,
            url: e.querySelector(sel.l)?.href || null,
        }))""",
        {"t": TITLE, "p": PRICE, "l": LINK},
    )


def main():
    t_start = time.perf_counter()
    check_robots()
    static_info = check_static()

    api_calls = []
    rounds_log = []
    stop_reason = None

    with sync_playwright() as pw:
        ARGS = ["--no-proxy-server"]
        try:
            browser = pw.chromium.launch(headless=True, args=ARGS)
        except Exception:
            log.warning("Встроенный Chromium не найден, запускаю установленный Edge")
            browser = pw.chromium.launch(headless=True, channel="msedge", args=ARGS)
        context = browser.new_context(user_agent=USER_AGENT, viewport={"width": 1366, "height": 900})
        page = context.new_page()

        # Этап 5: фиксируем XHR/fetch, чтобы найти JSON-эндпоинт (заголовки и токены НЕ сохраняем)
        def on_response(resp):
            if resp.request.resource_type in ("xhr", "fetch"):
                api_calls.append({
                    "url": resp.url, "method": resp.request.method, "status": resp.status,
                    "content_type": resp.headers.get("content-type", ""),
                })
        page.on("response", on_response)

        page.goto(TARGET_URL, wait_until="domcontentloaded")
        log.info("title: %s", page.title())

        # Этап 3: явное ожидание первых карточек
        page.wait_for_selector(CARD, state="visible", timeout=10_000)
        prev = page.eval_on_selector_all(CARD, "els => els.length")
        log.info("Первый экран: %d карточек", prev)
        rounds_log.append({"round": 0, "count": prev})

        # Этап 4: «Load more» до исчезновения кнопки / целевого объёма / стабилизации
        stable = 0
        for rnd in range(1, MAX_ROUNDS + 1):
            btn = page.locator(LOAD_MORE)
            if btn.count() == 0 or not btn.is_visible() or not btn.is_enabled():
                stop_reason = "кнопка «Load more» исчезла или отключена (данные исчерпаны)"
                break
            btn.scroll_into_view_if_needed()
            btn.click()
            try:
                page.wait_for_function(
                    "([sel, n]) => document.querySelectorAll(sel).length > n",
                    arg=[CARD, prev], timeout=WAIT_TIMEOUT_MS,
                )
            except PWTimeout:
                log.warning("Раунд %d: число карточек не выросло за %d мс", rnd, WAIT_TIMEOUT_MS)
            cur = page.eval_on_selector_all(CARD, "els => els.length")
            log.info("Раунд %d: %d -> %d карточек", rnd, prev, cur)
            rounds_log.append({"round": rnd, "count": cur})
            stable = stable + 1 if cur == prev else 0
            prev = cur
            if stable >= 3:
                stop_reason = "количество элементов стабилизировалось 3 раунда подряд"
                break
            page.wait_for_timeout(int(CLICK_DELAY_S * 1000))  # пауза вежливости, не ожидание готовности
        else:
            stop_reason = f"достигнут предел {MAX_ROUNDS} итераций"

        records = extract(page)
        browser.close()

    log.info("Причина остановки цикла: %s", stop_reason)

    # Этап 6: дедупликация и сохранение
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    df = pd.DataFrame(records)
    raw_n = len(df)
    df = df.drop_duplicates(subset=["url"]).reset_index(drop=True)
    df["collected_at_utc"] = now
    df.to_csv("dynamic_page_dataset.csv", index=False, encoding="utf-8-sig")
    log.info("Строк до дедупликации: %d, после: %d", raw_n, len(df))

    # Этап 7: метрики
    elapsed = time.perf_counter() - t_start
    json_calls = [c for c in api_calls if "json" in c["content_type"].lower()]
    metrics = {
        "target": TARGET_URL, "collected_at_utc": now,
        "static_check": static_info,
        "rounds": rounds_log, "stop_reason": stop_reason,
        "records_raw": raw_n, "records_unique": len(df),
        "nulls": df.isna().sum().to_dict(),
        "elapsed_s": round(elapsed, 2),
        "s_per_record": round(elapsed / max(len(df), 1), 4),
        "xhr_fetch_calls": api_calls, "json_calls_count": len(json_calls),
    }
    with open("metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    with open("network_log.json", "w", encoding="utf-8") as f:
        json.dump(api_calls, f, ensure_ascii=False, indent=2)
    log.info("Headless-сценарий: %.1f с на %d записей (%.3f с/запись)", elapsed, len(df), elapsed / max(len(df), 1))
    if len(df) < MIN_RECORDS:
        log.warning("Собрано меньше %d записей — проверьте селекторы/страницу", MIN_RECORDS)


if __name__ == "__main__":
    main()
